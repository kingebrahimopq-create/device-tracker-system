# البدء السريع - Device Tracker System

دليل سريع لتشغيل نظام متتبع الأجهزة في دقائق معدودة.

## 🚀 التثبيت السريع

### المتطلبات الأساسية
```bash
# تحقق من تثبيت Node.js
node --version  # يجب أن يكون 14 أو أحدث
npm --version   # يجب أن يكون 6 أو أحدث
```

### 1. استنساخ المشروع
```bash
cd /home/ubuntu/device-tracker-system
```

### 2. تثبيت الخادم
```bash
cd server
npm install
```

### 3. تثبيت العميل
```bash
cd ../client-app
npm install
```

## 🎯 التشغيل

### الطريقة 1: تشغيل منفصل (في نوافذ منفصلة)

**نافذة 1 - الخادم:**
```bash
cd /home/ubuntu/device-tracker-system/server
npm run dev
```

**نافذة 2 - العميل:**
```bash
cd /home/ubuntu/device-tracker-system/client-app
npm run dev
```

### الطريقة 2: تشغيل متزامن

```bash
cd /home/ubuntu/device-tracker-system

# تثبيت concurrently
npm install -g concurrently

# تشغيل الخادم والعميل معاً
concurrently "cd server && npm run dev" "cd client-app && npm run dev"
```

## 📊 اختبار النظام

### 1. التحقق من الخادم
```bash
curl http://localhost:3000/api/devices
```

يجب أن تحصل على استجابة JSON فارغة أو قائمة الأجهزة.

### 2. التحقق من العميل

عندما يبدأ العميل، يجب أن ترى:
```
📝 تسجيل الجهاز لدى الخادم...
✅ تم التسجيل بنجاح!
معرف الجهاز: [uuid]
مفتاح التشفير: [hex_key]
🚀 تطبيق العميل يعمل بنجاح
🔄 بدء خدمة الاتصال (كل 30 ثانية)
```

### 3. التحقق من الاتصال

في نافذة الخادم، يجب أن ترى:
```
✓ تم تسجيل جهاز جديد: [uuid]
```

## 📝 أمثلة الاستخدام

### إرسال أمر للعميل

```bash
curl -X POST http://localhost:3000/api/commands \
  -H "Content-Type: application/json" \
  -d '{
    "deviceId": "YOUR_DEVICE_ID",
    "type": "get_system_info",
    "payload": {}
  }'
```

### الحصول على قائمة الأجهزة

```bash
curl http://localhost:3000/api/devices
```

### الحصول على سجلات الجهاز

```bash
curl http://localhost:3000/api/logs/YOUR_DEVICE_ID
```

## 🔧 متغيرات البيئة

### للخادم (server/.env)
```
PORT=3000
NODE_ENV=development
```

### للعميل (client-app/.env)
```
SERVER_URL=http://localhost:3000
CLIENT_ID=client_123
CHECK_IN_INTERVAL=30
```

## 🛠️ استكشاف الأخطاء

### المشكلة: "Cannot find module"
```bash
# حل: أعد تثبيت المكتبات
rm -rf node_modules package-lock.json
npm install
```

### المشكلة: "Port 3000 is already in use"
```bash
# حل: استخدم منفذ مختلف
PORT=3001 npm run dev
```

### المشكلة: العميل لا يتصل بالخادم
```bash
# تحقق من أن الخادم يعمل
curl http://localhost:3000/api/devices

# تحقق من عنوان الخادم في العميل
# يجب أن يكون: http://localhost:3000
```

## 📊 مراقبة الأداء

### عرض السجلات في الوقت الفعلي

```bash
# للخادم
cd server && npm run dev 2>&1 | tee server.log

# للعميل
cd client-app && npm run dev 2>&1 | tee client.log
```

### استخدام htop لمراقبة الموارد

```bash
htop
```

## 🔐 الأمان

### تغيير مفتاح التشفير

```bash
# توليد مفتاح جديد
openssl rand -hex 32
```

### تفعيل HTTPS (للإنتاج)

```bash
# توليد شهادة SSL
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# استخدام HTTPS في الخادم
# تحديث server/index.ts لاستخدام https
```

## 📱 توليد APK

```bash
# اتبع التعليمات في APK_GENERATION.md
cd ../management-app
npm install
npm run build:apk
```

## 🎓 الخطوات التالية

1. **قراءة التوثيق الكامل**: اطلع على `README.md`
2. **فهم البروتوكول**: اقرأ قسم "الاتصال والبروتوكول" في README
3. **تطوير تطبيق الإدارة**: ابدأ بـ `management-app/`
4. **توليد APK**: اتبع `APK_GENERATION.md`
5. **الاختبار الشامل**: استخدم أدوات الاختبار

## 💡 نصائح مفيدة

### تصحيح الأخطاء (Debugging)

```bash
# تفعيل وضع التصحيح
DEBUG=* npm run dev
```

### استخدام Postman

1. قم بتحميل [Postman](https://www.postman.com/downloads/)
2. استورد الـ API endpoints من `postman-collection.json` (سيتم إنشاؤه)
3. اختبر جميع الـ endpoints

### استخدام VS Code

```bash
# فتح المشروع في VS Code
code /home/ubuntu/device-tracker-system
```

## 📞 الدعم والمساعدة

- اقرأ `README.md` للتوثيق الكامل
- اقرأ `APK_GENERATION.md` لتوليد APK
- تحقق من السجلات للأخطاء
- استخدم `console.log` للتصحيح

## 🎉 تم!

الآن لديك نظام Device Tracker يعمل بنجاح!

```
✅ الخادم يعمل على http://localhost:3000
✅ العميل متصل وجاهز
✅ الأوامر جاهزة للإرسال
✅ التشفير نشط
```

استمتع بالنظام! 🚀

---

**آخر تحديث:** 24 فبراير 2026
