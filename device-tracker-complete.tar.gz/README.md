# Device Tracker System - نظام متتبع الأجهزة المتقدم

نظام متكامل وآمن لتتبع الأجهزة وإدارتها عن بعد مع تشفير شامل وأوامر آمنة.

## 🏗️ بنية المشروع

```
device-tracker-system/
├── server/                 # خادم الإدارة
│   ├── index.ts           # نقطة دخول الخادم
│   ├── encryption.ts      # نظام التشفير
│   ├── models.ts          # نماذج البيانات
│   └── package.json
├── management-app/        # تطبيق الإدارة (React Native)
│   └── [ملفات التطبيق]
├── client-app/            # تطبيق العميل
│   ├── index.ts          # نقطة دخول العميل
│   ├── client-service.ts # خدمة الاتصال
│   └── package.json
└── README.md
```

## 🔐 الميزات الأمنية

### 1. التشفير المتقدم (AES-256-GCM)
- تشفير جميع الاتصالات بين العميل والخادم
- مفاتيح تشفير فريدة لكل جهاز
- التوقيع الرقمي والتحقق من السلامة
- حماية ضد هجمات Man-in-the-Middle

### 2. حظر الأوامر الخطرة
الأوامر التالية محظورة نهائياً:
- حذف الملفات (`rm -rf`)
- تنسيق الأقراص (`mkfs`, `format`)
- تعديل كلمات المرور
- الأوامر التي تتطلب صلاحيات إدارية

### 3. التحقق من الأمان
- التحقق من الكلمات المفتاحية المحظورة
- التحقق من صيغة الأوامر
- انتهاء صلاحية الأوامر (5 دقائق)

## 🚀 البدء السريع

### المتطلبات
- Node.js 14+
- npm أو yarn
- TypeScript

### 1. تثبيت الخادم

```bash
cd server
npm install
npm run dev
```

الخادم سيعمل على `http://localhost:3000`

### 2. تشغيل تطبيق العميل

```bash
cd client-app
npm install
npm run dev
```

### 3. تطبيق الإدارة

```bash
cd management-app
npm install
npm run dev
```

## 📡 الاتصال والبروتوكول

### دورة الاتصال

```
العميل                           الخادم
  |                              |
  |--- POST /api/clients/register ---|
  |<--- deviceId + encryptionKey ---|
  |                              |
  |--- POST /api/clients/checkin ---|  (كل 30 ثانية)
  |<--- الأوامر المعلقة --------|
  |                              |
  |--- POST /api/clients/report ---|
  |<--- تأكيد الاستقبال --------|
```

### تشفير البيانات

جميع البيانات المرسلة مشفرة بصيغة:
```
IV:TAG:ENCRYPTED_DATA
```

حيث:
- `IV`: Initialization Vector (16 بايت)
- `TAG`: Authentication Tag (16 بايت)
- `ENCRYPTED_DATA`: البيانات المشفرة

## 🎮 الأوامر المدعومة

### 1. الأوامر الأساسية
- `get_system_info`: الحصول على معلومات النظام
- `ping`: التحقق من الاتصال
- `sync`: مزامنة البيانات

### 2. أوامر المراقبة
- `get_location`: الحصول على الموقع الجغرافي
- `get_logs`: الحصول على السجلات
- `take_screenshot`: التقاط لقطة شاشة

### 3. أوامر التنفيذ
- `execute_shell`: تنفيذ أمر shell
- `run_script`: تشغيل سكريبت

### 4. أوامر الملفات
- `list_files`: عرض قائمة الملفات
- `read_file`: قراءة ملف

## 📊 معلومات النظام المجمعة

يجمع العميل المعلومات التالية:
- اسم الجهاز
- نوع النظام (OS)
- إصدار النظام
- معمارية المعالج
- عدد المعالجات
- إجمالي الذاكرة
- الذاكرة المتاحة
- وقت التشغيل
- الموقع الجغرافي (عند الطلب)

## 🔧 متغيرات البيئة

### الخادم
```bash
PORT=3000                    # منفذ الخادم
NODE_ENV=development        # بيئة التطوير
```

### العميل
```bash
SERVER_URL=http://localhost:3000    # عنوان الخادم
CLIENT_ID=client_123                # معرف العميل
DEVICE_ID=device_uuid               # معرف الجهاز (اختياري)
ENCRYPTION_KEY=hex_key              # مفتاح التشفير (اختياري)
CHECK_IN_INTERVAL=30                # فترة الاتصال بالثواني
```

## 📝 API الخادم

### تسجيل العميل
```
POST /api/clients/register
Content-Type: application/json

{
  "clientId": "client_123",
  "deviceInfo": {
    "deviceName": "My Device",
    "osType": "Android",
    "osVersion": "12",
    "appVersion": "1.0.0"
  }
}

Response:
{
  "success": true,
  "deviceId": "uuid",
  "encryptionKey": "hex_key"
}
```

### الاتصال الدوري
```
POST /api/clients/checkin
Content-Type: application/json

{
  "deviceId": "uuid",
  "encryptedData": "iv:tag:encrypted"
}

Response:
{
  "success": true,
  "encryptedData": "iv:tag:encrypted"
}
```

### إرسال أمر
```
POST /api/commands
Content-Type: application/json

{
  "deviceId": "uuid",
  "type": "execute_shell",
  "payload": {
    "command": "ls -la"
  }
}

Response:
{
  "success": true,
  "commandId": "uuid"
}
```

### الحصول على الأجهزة
```
GET /api/devices

Response:
[
  {
    "id": "uuid",
    "name": "My Device",
    "status": "online",
    "lastSeen": "2024-02-24T12:00:00Z",
    "osType": "Android",
    "osVersion": "12"
  }
]
```

## 🛡️ الأمان والخصوصية

### مبادئ الأمان
1. **التشفير من طرف إلى طرف**: جميع الاتصالات مشفرة
2. **المصادقة**: كل جهاز له معرف ومفتاح فريد
3. **التحقق من السلامة**: استخدام HMAC للتحقق من عدم التعديل
4. **حظر الأوامر الخطرة**: منع الأوامر التي قد تضر النظام
5. **انتهاء الصلاحية**: الأوامر تنتهي صلاحيتها بعد 5 دقائق

### حماية البيانات
- لا يتم تخزين كلمات المرور
- لا يتم تخزين البيانات الحساسة بدون تشفير
- جميع السجلات مشفرة

## 📱 توليد APK للعميل

سيتم توليد APK مخصص لكل جهاز يحتوي على:
- معرف الجهاز الفريد
- مفتاح التشفير
- عنوان الخادم
- إعدادات الاتصال

```bash
# سيتم توليد APK من خلال تطبيق الإدارة
# الخطوات:
# 1. اضغط على "توليد APK جديد"
# 2. اختر اسم الجهاز
# 3. سيتم توليد APK مخصص
# 4. قم بتحميل وتثبيت APK على الجهاز
```

## 🧪 الاختبار

### اختبار الخادم
```bash
cd server
npm run dev
```

### اختبار العميل
```bash
cd client-app
npm run dev
```

### اختبار التشفير
```bash
# سيتم إضافة اختبارات شاملة
npm run test
```

## 📊 المراقبة والسجلات

### السجلات المتاحة
- سجلات الاتصال
- سجلات الأوامر
- سجلات الأخطاء
- سجلات الأمان

### عرض السجلات
```bash
GET /api/logs/:deviceId
```

## 🐛 استكشاف الأخطاء

### المشكلة: العميل لا يتصل بالخادم
- تحقق من عنوان الخادم
- تأكد من أن الخادم يعمل
- تحقق من جدار الحماية

### المشكلة: فشل التشفير
- تأكد من أن مفتاح التشفير صحيح
- تحقق من صيغة البيانات المشفرة

### المشكلة: الأوامر لا تنفذ
- تحقق من أن الأمر آمن
- تأكد من أن الجهاز متصل
- تحقق من السجلات للأخطاء

## 📚 المراجع

- [Express.js Documentation](https://expressjs.com/)
- [Node.js Crypto Module](https://nodejs.org/api/crypto.html)
- [TypeScript Documentation](https://www.typescriptlang.org/)

## 📄 الترخيص

هذا المشروع مرخص تحت MIT License

## 👥 المساهمون

تم تطويره بواسطة فريق Device Tracker

---

**آخر تحديث:** 24 فبراير 2026  
**الإصدار:** 1.0.0  
**الحالة:** قيد التطوير
